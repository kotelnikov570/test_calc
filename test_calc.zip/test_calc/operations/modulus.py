def modulus(a, b):
    return a % b
